Introducción
-----------
"Quien posea el poder de invocar toda clase de criaturas inimagiables, tiene el mismo poder que un dios."

Este programa, no es más que un grimorio digital, un libro que permita invocar héroes, criaturas o demonios. Pretendo que cada lector pueda incluir sus páginas, a su gusto, permitiendo así crear todos los personajes que deseen para sus partidas. 
El Libro de Esher ha sido desarrollado por Jorge Hortelano Otero. Espero que te sea realmente útil a la hora de evitar el tedioso trabajo de realizar un PJ o simplemente te ayude con tus PNJs. 
Lo distribuyo como software libre, asi que puedes utilizarlo o modificarlo a tu gusto mientras dejes estas palabras y el nombre del autor original (osease, yo).  Para más información leete la licencia GNU en el fichero adjunto. 

Instalacion:
----------
Este programa esta desarrollado en java, por tanto necesita la maquina virtual java para que funcione. La maquina virtual java puede ser descargada gratuitamente desde aqui: http://www.java.com/es/download/


Ejecucion:
---------
Para ejecutar el program escribir en consola:
"java -jar dist\LibroDeEsher.jar"

O utilizar los ficheros Linux.sh o Windows.bat dependiendo del sistema operativo utilizado. Este script intentará buscar la última versión de java en tu sistema y ejecutarlo. 

Subida de Nivel Remota:
----------
Desde la versión 0.98 existe la posibilidad de que los jugadores se suban el nivel de su personaje en casa, tranquilamente y sin supervisión alguna. Esto se ha hecho intentando que sea la forma más segura posible y evitar que estos hagan trampas. Para ello, el DJ como el jugador tiene un copia del personaje en sus respectivos ordenadores. El jugador puede utilizar este programa de forma que puede gastar sus puntos de desarrollo como desee según las normas establecidas. Una vez hecho, debe de exportar SOLAMENTE la subida de nivel y no todo el persoanje, y enviarlo por email al DJ. El DJ actualiza la versión del personaje de la que dispone en su ordenador, mostrando los puntos de desarrollo que se han gastado (y comprobar que no se han gastado de más) e imprimiendo la ficha después. 
Para la siguiente subida de nivel, es aconsejable que el DJ vuelva a enviar el personaje actualizado al jugador. Lo que no se debe hacer nunca es que el DJ cambie el fichero con la ficha de personaje por la ficha de personaje del jugador, ya que este si que puede haber sido alterado. 
Con esta metodología se ahorra tiempo en las partidas, reuniendo a los jugadores solamente para jugar y no para realizar modificaciones en las fichas. 


Problemas posibles
----------
Existe un problema conocido con el generador de personajes. Normalmente se debe a que los ficheros con las características y las habilidades se bajan en un formato extraño (ocurre en Windows en la mayoría de ordenadores). Si te pasa este problema (lo reconocerás por que al abrir el fichero rolemaster/características.txt los acentos se ven de forma extraña), visita la página web del Libro de Esher y descargate el fichero rolemaster_win.zip y sustituye el contenido del programa por el de este fichero.


Versión
------------
0.991	Añadido:
		- Profesiones pueden tener varios listados de habilidades comunes.
		- Mejorada la inteligencia para crear personajes aleatorios.
		- Se permiten sugerir adiestramientos al crear personajes aleatorios.
		- Existen habilidades restringidas por defecto.
		- Los talentos tienen nuevas opciones. 
		- PDF de la hoja combinada de habilidades.

0.990	Cambiado:
		- Las categorías se separan por módulos, de forma que se pueden añadir sin tener que cambiar el fichero original. 
		- Corregido un pequeño problema al insertar personaje si este no tenía nombre definido. 
		- Se pueden sugerir rangos en categorías y habilidades al crear un personaje aleatorio. 
		- Al guardar ficheros se pueden seleccionar carpetas. 
		
0.980	Añadido:
		- La puntuación máxima de las características ya no está limitada a 660. 
		- Las razas pueden tener culturas por patrones: ej. Todas las Urbanas. 
		- Se permiten exportar subidas de nivel de forma segura. Esto permite a un jugador subirse el nivel en su casa y luego enviarlo al DJ para que lo confirme y lo imprima.
		Corregido:
		- Las opciones se guardan ahora en el directorio del usuario, corrigiendo un posible error de escritura. 
		- Solucionado error al generar las TRs de Enfermedades y Venenos
		
0.975	Cambios:
		- Corregido un fallo que impide seleccionar cualquier idioma con los puntos de desarrollo.
		- Al cargar un PJ antiguo, se le añaden las nuevas categorías que aparecen en el fichero categorias.txt si estas no existían cuando se generó el personaje.
		- Ya no se pierden los puntos de desarrollo en los idiomas de la cultura. 

0.9741	Cambios:
		- Corregido un error en los talentos de personaje que impide visualizarlos correctamente. 
		- Apariencia de Windows para las ventanas si se ejecuta en Windows. Apariencia GTK para los usuarios de Linux.
		
0.974	Cambios:
		- Soluciona un fallo que impide utilizar las flechas para aumentar los rangos de las habilidades comunes.
		- Soluciona varios fallos generados al asignar habilidades generales al insertar un PJ.
		- Solucionado que los nombres de habilidades grandes desmonten algunas ventanas.
		- Los adiestramientos al insertar personaje salen ordenados alfabéticamente.
		- Al exportar a PDF, se perdía alguna habilidad si se necesitaba más de una página para mostrarlas. 
		- Talentos ahora presentan un listado de habilidades para elegir si es necesario.
		- Se pueden gastar puntos de historial para obtener objetos mágicos.
		- Las fichas en formato texto reflejan las armaduras naturales u obtenidas por los talentos.
		- Solucionado problema que impide a los adiestramientos seleccionar armas de fuego correctamente.
		
0.973	Cambios:
		- Desarrollo Físico tiene +10 en la categoría extra como indica el reglamento.
		- (Solucionado) Los objetos mágicos con bonus en las categorias los pone en bonificacion por profesion.
		- (Solucionado) Los objetos imprimen las habilidades y categorias que están a cero. 
		- (Solucionado) Al Insertar un Personaje, al añadir objetos no borra los bonus del anterior.
		- (Solucionado) Fallo en las habilidades al imprimir en PDF.
		- (Solucionado) Error que ignora el bonus de profesión a la primera categoría de la lista.
		- (Solucionado) Ignore listas de hechizos con el mismo nombre de profesiones distintas.
		- (Solucionado) Al insertar personaje, se añaden los hechizos de adiestramiento como básica (aunque no se tenga el adiestramiento).
		- Se incluye la capacidad de movimiento en las fichas y se aplican los talentos que la modifiquen.
		- (Solucionado) Error que permite subir caracteristicas con puntos de historial indefinidamente.
		- Los adiestramientos aparecen ordenados alfabéticamente.
		- Cuando se añaden las armas de fuego (hay 9 categorias de armas en vez de 7), las últimas dos categorías de armas elegidas sin coste definido tienen el coste en rangos similar a la 7º, y no un coste de 20 PD como era antes.
		- Ahora al insertar personaje, se puede definir habilidades especializadas y generales.
		- Separación de armas en generalizaciones.
		- Los talentos pueden dar una habilidad como común a escoger por el usuario de entre las de una categoría.
		- Los talentos pueden incluir TRs (Esencia, Frío, etc.).
		- (Solucionado) Los personajes aleatorio también cogen el equipo de los adiestramientos.
		- Los mensajes de error se dividen en varias líneas si es necesario.
		- Ahora hay habilidades que pueden ser requisitos de otras habilidades (como ocurre con los poderes chi).
		- Añade una opción que permite usar el sistema de artes marciales golpes y barridos (divididos en cuatro grados) o el nuevo de la guía de artes marciales que es una única habilidad.
		
0.972	Corrección del error que impide leer los ficheros en Windows Vista. 

0.971	Corrección de bugs a la hora de generar un personaje elementalista aleatorio.

0.970	Se incluyen las reglas particulares de los elementalistas. 

0.961	Personajes aleatorios también cogen habilidades especializadas y generales.

0.960	Habilidades especializadas y generales.

0.957	Visualización gráfica de errores.

0.956	Se guarda las opciones seleccionadas para futuros usos. Se corrigen más bugs.

0.955	Los adiestramientos ya incluyen hechizos.
		Los talentos se pueden restringir a razas particulares.
		Se pueden insertar talentos.
		Los hechizos oscuros pueden ser listas básicas.
		
0.954	Se pueden gastar puntos de historial para subir caracteristicas.
		Los adiestramientos permiten elegir caracteristica para subir.
		Los talentos permiten bonus a las características.
		
0.9531	Equipo de adiestramientos y su listado en las hojas de personaje.

0.953	Talentos para PJs y PNJs.

0.952	Corrección de bugs al guardar el personaje, corrección de bugs en los adiestramientos

0.951	Mejora del Rendimiento de las Ventanas

0.950	Insertar Categorias y Habilidades

0.940	Añadir módulos al programa,  Añadir bonus especiales a las habilidades

0.930	Inserción de Personajes

0.920	Corrección de algunos bugs

0.900	Exportar a PDF y a TXT

0.800	Personajes Aleatorios

0.710	Corrección de algunos bugs

0.700	Adiestramientos

0.600	Culturas


Mas información
-------------------------

http://librodeesher.sourceforge.net

Bugs, ideas, errores y demas a :
softwaremagico@gmail.com
